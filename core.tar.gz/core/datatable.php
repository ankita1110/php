<html>
  <head>
    <script src="../jquery.min.js"></script>
    <script src="../datatables/media/js/jquery.dataTables.js">
    </script>
    <style type="text/css">
      @import "../datatables/media/css/demo_table.css";</style>
    <script>
      $(document).ready(function(){
        $('#the_table').dataTable();
      });
    </script>
  </head>
  <body>
    <div style="width:500px">
      <table id="the_table">
        <thead>
          <tr>
            <th>Artist / Band</th><th>Album</th><th>Song</th>
          </tr>
        </thead>
        <tbody>
          <tr><td>Muse</td>
              <td>Absolution</td>
              <td>Sing for Absolution</td>
          </tr>
          <tr><td>Primus</td>
            <td>Sailing The Seas Of Cheese</td>
            <td>Tommy the Cat</td>
          </tr>
          <tr><td>Nine Inch Nails</td>
              <td>Pretty Hate Machine</td>
              <td>Something I Can Never Have</td>
          </tr>
          <tr><td>Horslips</td>
            <td>The Táin</td>
            <td>Dearg Doom</td>
          </tr>
          <tr><td>Muse</td>
              <td>Absolution</td>
              <td>Hysteria</td>
          </tr>
          <tr><td>Alice In Chains</td>
            <td>Dirt</td>
            <td>Rain When I Die</td>
          </tr>
          <!-- PLACE MORE SONGS HERE -->
        </tbody>
      </table>
    </div>
  </body>
</html>
