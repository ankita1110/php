<?php
include("con.php");
$name=$_REQUEST['fname'];
$city=$_REQUEST['city'];
echo $name;
echo $city;
/*
$sql = "insert into std (name, city)values('$name', '$city')";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
    header('location:ankita.php');
} else {
    echo "not inserting";
}
*/


?>