<?php
$re=$_REQUEST['d1'];
$con=mysqli_connect("localhost","root","LANETTEAM1",$re);
?>

<?php
$q1 = $_REQUEST['tbl'];
$select="select * from $q1";
//echo $select;
$sel=mysqli_query($con,$select);
if(mysqli_num_rows($sel)>0)
{
    while($se=mysqli_fetch_array($sel))
    {
        echo $se['name'];

    }
}
else
{
    echo "not data found";
}
?>
