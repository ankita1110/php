<script src="https://code.jquery.com/jquery-1.12.4.min.js">
</script>

<form method="post">
    select
    <select name="getd" id="getd">
        <option>---select---</option>
        <option>hemin</option>
        <option>nikita</option>
        <option>sahil</option>
    </select>
<div id="output"></div>
</form>


<script>
    $(document).ready(function(){
        $("#getd").change(function(){

          // var s="";
           // alert("hi");
            //$s=$_REQUEST['getd'];
            var selecteddata = $("#getd").val();

            //alert(selectedCountry);
            $.ajax({
                type: "POST",
                url: "data.php?name="+selecteddata,
                data: { showdata : selecteddata } ,

                success: function(data)  {

                    //alert(data);
                    $("#output").html(data);
                }
            });
        });
    });

    </script>